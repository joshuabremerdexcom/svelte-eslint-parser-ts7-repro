[![NPM license](https://img.shields.io/npm/l/svelte-eslint-parser.svg)](https://www.npmjs.com/package/svelte-eslint-parser)
[![NPM version](https://img.shields.io/npm/v/svelte-eslint-parser.svg)](https://www.npmjs.com/package/svelte-eslint-parser)
[![NPM downloads](https://img.shields.io/badge/dynamic/json.svg?label=downloads&colorB=green&suffix=/day&query=$.downloads&uri=https://api.npmjs.org//downloads/point/last-day/svelte-eslint-parser&maxAge=3600)](http://www.npmtrends.com/svelte-eslint-parser)
[![NPM downloads](https://img.shields.io/npm/dw/svelte-eslint-parser.svg)](http://www.npmtrends.com/svelte-eslint-parser)
[![NPM downloads](https://img.shields.io/npm/dm/svelte-eslint-parser.svg)](http://www.npmtrends.com/svelte-eslint-parser)
[![NPM downloads](https://img.shields.io/npm/dy/svelte-eslint-parser.svg)](http://www.npmtrends.com/svelte-eslint-parser)
[![NPM downloads](https://img.shields.io/npm/dt/svelte-eslint-parser.svg)](http://www.npmtrends.com/svelte-eslint-parser)
[![Build Status](https://github.com/sveltejs/svelte-eslint-parser/workflows/CI/badge.svg?branch=main)](https://github.com/sveltejs/svelte-eslint-parser/actions?query=workflow%3ACI)
[![Coverage Status](https://coveralls.io/repos/github/sveltejs/svelte-eslint-parser/badge.svg?branch=main)](https://coveralls.io/github/sveltejs/svelte-eslint-parser?branch=main)

<div align="center">

# svelte-eslint-parser

## [Svelte](https://svelte.dev/) parser for [ESLint](https://eslint.org/)

[Live DEMO](https://sveltejs.github.io/svelte-eslint-parser/playground) •
[Discord](https://svelte.dev/chat)

</div>

## Motivation

The `svelte-eslint-parser` aims to make it easy to create your own ESLint rules for [Svelte](https://svelte.dev/).

[eslint-plugin-svelte](https://github.com/sveltejs/eslint-plugin-svelte) is an ESLint plugin built upon this parser, and it already [implements some rules](https://sveltejs.github.io/eslint-plugin-svelte/rules/).

### ESLint Plugins Using svelte-eslint-parser

#### [eslint-plugin-svelte](https://sveltejs.github.io/eslint-plugin-svelte/)

ESLint plugin for Svelte.  
Provides a variety of template-based checks using the Svelte AST.

#### [@intlify/eslint-plugin-svelte](https://github.com/intlify/eslint-plugin-svelte)

ESLint plugin for internationalization (i18n) in Svelte applications, offering helpful i18n-related rules.

---

## Installation

```bash
npm install --save-dev eslint svelte-eslint-parser
```

---

## Usage

### ESLint Config (`eslint.config.js`)

```js
import js from "@eslint/js";
import svelteParser from "svelte-eslint-parser";

export default [
  js.configs.recommended,
  {
    files: [
      "**/*.svelte",
      "*.svelte",
      // Need to specify the file extension for Svelte 5 with rune symbols
      "**/*.svelte.js",
      "*.svelte.js",
      "**/*.svelte.ts",
      "*.svelte.ts",
    ],
    languageOptions: {
      parser: svelteParser,
    },
  },
];
```

### CLI

```bash
eslint "src/**/*.{js,svelte}"
```

---

## Options

The [parserOptions](https://eslint.org/docs/latest/use/configure/parser#configure-parser-options) for this parser generally match what [espree](https://github.com/eslint/espree#usage)—ESLint's default parser—supports.

For example:

```js
import svelteParser from "svelte-eslint-parser";

export default [
  // ...
  {
    files: [
      // Set .svelte/.js/.ts files. See above for more details.
    ],
    languageOptions: {
      parser: svelteParser,
      parserOptions: {
        sourceType: "module",
        ecmaVersion: 2024,
        ecmaFeatures: {
          globalReturn: false,
          impliedStrict: false,
          jsx: false,
        },
      },
    },
  },
];
```

### parserOptions.parser

Use the `parserOptions.parser` property to define a custom parser for `<script>` tags. Any additional parser options (besides the parser itself) are passed along to the specified parser.

```js
import ts from "typescript-eslint";

export default [
  {
    files: [
      // Set .svelte/.js/.ts files. See above for more details.
    ],
    languageOptions: {
      parser: svelteParser,
      parserOptions: {
        parser: ts.parser,
      },
    },
  },
];
```

#### Using TypeScript in `<script>`

If you use the parser from [typescript-eslint](https://typescript-eslint.io/) (`ts.parser`, a re-export of `@typescript-eslint/parser`) for TypeScript within `<script>` of `.svelte` files, additional configuration is needed. For example:

```js
import ts from "typescript-eslint";

export default [
  // Other config for non-Svelte files
  {
    languageOptions: {
      parser: ts.parser,
      parserOptions: {
        project: "path/to/your/tsconfig.json",
        extraFileExtensions: [".svelte"],
      },
    },
  },
  // Svelte config
  {
    files: [
      // Set .svelte/.js/.ts files. See above for more details.
    ],
    languageOptions: {
      parser: svelteParser,
      // Parse the `<script>` in `.svelte` as TypeScript by adding the following configuration.
      parserOptions: {
        parser: ts.parser,
      },
    },
  },
];
```

#### Using JSDoc types in JavaScript

The configuration above also supports JSDoc type annotations in JavaScript
`<script>` blocks (with no `lang`, `lang="js"`, or `lang="javascript"`) and
`.svelte.js` files. Configure `parserOptions.project` or
`parserOptions.projectService` to enable type-aware lint rules.

```svelte
<script>
  /** @param {number} value */
  function increment(value) {
    return value + 1;
  }
</script>

{increment(1)}
```

When using multiple parsers, assign `ts.parser` to the `js`
entry as well as `ts` to enable JSDoc type information in ordinary `<script>`
blocks. JavaScript configured to use Espree continues to use Espree.

#### Multiple parsers

To switch parsers for each language, provide an object:

```js
import ts from "typescript-eslint";
import espree from "espree";

export default [
  {
    files: [
      // Set .svelte/.js/.ts files. See above for more details.
    ],
    languageOptions: {
      parser: svelteParser,
      parserOptions: {
        parser: {
          ts: ts.parser,
          js: espree,
          typescript: ts.parser,
        },
      },
    },
  },
];
```

### parserOptions.svelteConfig

You can pass your Svelte config to the parser via `parserOptions.svelteConfig`.

In SvelteKit 3 projects, the Svelte config is passed to the `sveltekit()` plugin in `vite.config.js`. Plain Vite projects can also pass it to the `svelte()` plugin. Use [`@sveltejs/load-config`](https://www.npmjs.com/package/@sveltejs/load-config) to load it. It reads both `vite.config.js` and `svelte.config.js`.

```js
import { loadConfig } from "@sveltejs/load-config";

const svelteConfig = (await loadConfig("./", { traverse: false }))?.config;

export default [
  {
    files: [
      // Set .svelte/.js/.ts files. See above for more details.
    ],
    languageOptions: {
      parser: svelteParser,
      parserOptions: {
        svelteConfig,
      },
    },
  },
];
```

If you use `svelte.config.js`, you can also import it directly: `import svelteConfig from "./svelte.config.js";`.

If `parserOptions.svelteConfig` is not set, the parser attempts to statically read some config from `svelte.config.js`. It does not read `vite.config.js`. If you put the Svelte config in `vite.config.js`, pass it via `parserOptions.svelteConfig`.

### parserOptions.svelteFeatures

You can configure how Svelte-specific features are parsed via `parserOptions.svelteFeatures`.

For example:

```js
export default [
  {
    files: [
      // Set .svelte/.js/.ts files. See above for more details.
    ],
    languageOptions: {
      parser: svelteParser,
      parserOptions: {
        svelteFeatures: {
          // This is for Svelte 5. The default is true.
          // If false, ESLint won't recognize rune symbols.
          // If not specified, the parser first uses `<svelte:options runes>` in the file.
          // If that is not set, it reads compilerOptions.runes from the Svelte config.
          // If `parserOptions.svelteConfig` is not given and static analysis fails, it defaults to true.
          runes: true,
        },
      },
    },
  },
];
```

---

## Experimental

### `ts.sys.readFile` hook for type-aware Svelte lint

> ⚠️ **Experimental.** Opt-in only; behavior may change or be removed.

Speeds up type-aware lint of `.svelte` files. Your ESLint config must
already list `.svelte` via `parserOptions.extraFileExtensions`.

```sh
SVELTE_ESLINT_PARSER_EXPERIMENTAL_TS_SYS_HOOK=1 \
  eslint --no-cache --concurrency auto .
```

When enabled, the hook also resolves `.svelte` import specifiers to the
imported component's virtual module, so type-aware rules see a component's
real prop, event, and slot types across files. `import Foo from "./Foo.svelte"`
is resolved through a virtual `Foo.svelte.ts` companion that the hook serves
from the same translation — no `tsconfig` changes are required. If a real
`Foo.svelte.ts` (a Svelte runes module) exists on disk, it always takes
precedence and the hook leaves it untouched. In that case component prop types
are not available for that component, because plain TypeScript resolution picks
the module instead of the component. To avoid this name collision, enable the
`svelte/no-conflicting-module-names` rule from `eslint-plugin-svelte` (v3.22.0
or later), which reports a `Foo.svelte` and `Foo.svelte.ts` pair.

Component typing currently requires a TypeScript `<script>` and supports
Svelte 3, 4, and 5. Props come from `$props()` annotations or destructuring
in runes mode, and from `$$Props` or exported `let` bindings in legacy mode.
Defaulted props are optional. Explicit `$$Events` and `$$Slots` declarations
supply event and slot types; otherwise those types remain permissive.
Instance exports (`export const`, `export function`, `export class`, and
`export { … }` in the instance script) are part of the component instance type,
so a `bind:this` target typed as the component sees them.

This is not a full replacement for Svelte's generated component declarations.
Unannotated props without defaults use `any`, rest props keep the prop type
open, and generic parameters are represented by their constraints rather than
preserving a generic component signature. Slot types inferred from template
markup are not synthesized. JavaScript-only components do not receive this
TypeScript translation.

Caveat: rules that read raw TypeScript diagnostics
(`program.getSemanticDiagnostics()` and friends) report positions inside
the parser's virtual shim — a pre-existing property of type-aware Svelte
lint, not specific to the hook.

---

## Editor Integrations

### Visual Studio Code

Use the [dbaeumer.vscode-eslint](https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint) extension provided by Microsoft.

By default, it only targets `*.js` and `*.jsx`, so you need to configure `.svelte` file support. For example, in **.vscode/settings.json**:

```json
{
  "eslint.validate": ["javascript", "javascriptreact", "svelte"]
}
```

---

## Usage for Custom Rules / Plugins

- See [AST.md](./docs/AST.md) for the AST specification. You can explore it on the [Live DEMO](https://sveltejs.github.io/svelte-eslint-parser/).
- This parser generates its own [ScopeManager](https://eslint.org/docs/developer-guide/scope-manager-interface). Check the [Live DEMO](https://sveltejs.github.io/svelte-eslint-parser/scope).
- Several rules are [already implemented] in [`eslint-plugin-svelte`], and their source code can be a helpful reference.

---

## Contributing

Contributions are welcome! Please open an issue or submit a PR on GitHub.  
For internal details, see [internal-mechanism.md](./docs/internal-mechanism.md).

---

## License

See [LICENSE](LICENSE) (MIT) for rights and limitations.
