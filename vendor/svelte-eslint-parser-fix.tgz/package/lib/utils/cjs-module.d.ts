/** Load the newest reachable copy of a module (linter → cwd → self). */
export declare function loadNewestModule<T>(module: string): T;
/**
 * Load the TypeScript that typescript-eslint uses to create the program,
 * falling back to the newest reachable copy.
 */
export declare function loadTypeScript<T>(): T;
/** Resolve `typescript` from `@typescript-eslint/typescript-estree`, starting where `@typescript-eslint/parser` is installed. */
export declare function resolveTypeScriptFromTSESLint<T>(requires: (NodeJS.Require | null)[]): T | null;
